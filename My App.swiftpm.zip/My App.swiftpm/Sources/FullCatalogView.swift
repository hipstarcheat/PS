import SwiftUI

struct FullCatalogView: View {
    @StateObject private var viewModel = FullCatalogViewModel()
    @State private var currentLevel: Int = 0  // Уровень (0 - бренды, 1 - модели, 2 - вкусы)
    @State private var selectedBrand: FullCatalogItem? = nil
    @State private var selectedModel: FullCatalogItem? = nil
    @State private var selectedTaste: FullCatalogItem? = nil  // Для хранения выбранного вкуса
    @Binding var selectedTab: Int  // Привязка к текущей вкладке
    
    var body: some View {
        NavigationView {
            VStack {
                TextField("Поиск", text: $viewModel.searchQuery)
                    .padding()
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                if viewModel.isLoading {
                    ProgressView("Загрузка...")
                } else {
                    List(viewModel.filteredItems) { item in
                        Button(action: {
                            switch currentLevel {
                            case 0:  // Переход на уровень моделей
                                selectedBrand = item
                                currentLevel = 1
                                viewModel.filterModels(for: item)
                            case 1:  // Переход на уровень вкусов
                                selectedModel = item
                                currentLevel = 2
                                viewModel.filterTastes(for: item)
                            case 2:  // Выбор вкуса
                                selectedTaste = item
                            default:
                                break
                            }
                        }) {
                            Text(item.title)
                        }
                    }
                }
                
                // Переход на экран с подробным описанием вкуса
                NavigationLink(
                    destination: TasteDetailView(taste: selectedTaste),
                    isActive: Binding(
                        get: { selectedTaste != nil },
                        set: { if !$0 { selectedTaste = nil } }
                    )
                ) {
                    EmptyView()
                }
            }
            .navigationTitle(currentLevel == 0 ? "Бренды" : currentLevel == 1 ? "Модели" : "Вкусы")
            .onAppear {
                if selectedTab == 1 {
                    viewModel.loadAllData()
                }
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    if currentLevel > 0 {
                        Button("Назад") {
                            resetCurrentLevel()
                        }
                    }
                }
            }
        }
    }
    
    private func resetToBrands() {
        currentLevel = 0
        viewModel.filteredItems = viewModel.allBrands
    }
    
    // Сброс текущего уровня и перезагрузка данных
    private func resetCurrentLevel() {
        switch currentLevel {
        case 2:  // Из вкусов в модели
            currentLevel = 1
            selectedTaste = nil
            if let selectedBrand = selectedBrand {
                viewModel.filterModels(for: selectedBrand)
            }
        case 1:  // Из моделей в бренды
            currentLevel = 0
            selectedModel = nil
            viewModel.resetToBrands()
        default:
            break
        }
    }
}

struct TasteDetailView: View {
    let taste: FullCatalogItem?
    
    var body: some View {
        VStack {
            if let taste = taste {
                Text(taste.title)
                    .font(.largeTitle)
                    .padding()
                if let description = taste.description {
                    Text("Артикул для ввода в МойСклад: \(description)")
                        .padding()
                        .foregroundColor(.blue)
                }
            } else {
                Text("Выберите вкус для подробностей.")
                    .padding()
            }
        }
        .navigationTitle("Описание Вкуса")
    }
}
